import pygame, sys
from pygame.locals import *

rocketImg = pygame.image.load('images/rocket1.png')
rx = 210
ry = 240

BLACK = (0,0,0)

pygame.init()
DISPLAY = pygame.display.set_mode((480,360))

while True:
    DISPLAY.fill(BLACK)
    DISPLAY.blit(rocketImg, (rx,ry))

    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
    
    pygame.display.update()

