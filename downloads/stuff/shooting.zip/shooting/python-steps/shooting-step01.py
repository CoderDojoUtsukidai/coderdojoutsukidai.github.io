import pygame
from pygame.locals import *

BLACK = (0,0,0)

pygame.init()
DISPLAY = pygame.display.set_mode((480,360))

while True:
    DISPLAY.fill(BLACK)
    pygame.display.update()

