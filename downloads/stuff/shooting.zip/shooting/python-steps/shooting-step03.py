import pygame, sys
from pygame.locals import *

rocketImg = pygame.image.load('images/rocket1.png')
rx = 210
ry = 240

BLACK = (0,0,0)

pygame.init()
DISPLAY = pygame.display.set_mode((480,360))

while True:
    DISPLAY.fill(BLACK)
    DISPLAY.blit(rocketImg, (rx,ry))

    for event in pygame.event.get():
        if pygame.key.get_pressed()[pygame.K_LEFT] != 0:
            if rx > 0:
                rx = rx - 10
        elif pygame.key.get_pressed()[pygame.K_RIGHT] != 0:
            if rx < 430:
                rx = rx + 10
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
    
    pygame.display.update()

