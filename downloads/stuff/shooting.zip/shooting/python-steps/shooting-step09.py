import pygame, sys, time, random
from pygame.locals import *

rocketImg = pygame.image.load('images/rocket1.png')
rx = 210
ry = 240

beams = []
lastBeamUpdateTime = 0
BEAM_UPDATE_DELAY = 0.1 # sec

alienImg = []
for i in range(10):
    alienImg.append(pygame.image.load('images/alien'+str(i+1)+'.png'))

aliens = []
alien = { 'costume': random.randint(0,9), 'position': [random.randint(0, 479), 20] }
aliens.append(alien)
lastAlienUpdateTime = 0
ALIEN_UPDATE_DELAY = 0.5 # sec
nextAlienStartTime = time.time() + 6

BLACK = (0,0,0)
WHITE = (255,255,255)

pygame.init()
DISPLAY = pygame.display.set_mode((480,360))

while True:
    DISPLAY.fill(BLACK)
    DISPLAY.blit(rocketImg, (rx,ry))

    for b in beams:
        pygame.draw.rect(DISPLAY, WHITE, (b[0]-2, b[1]-8, 4, 16))
    for a in aliens:
        DISPLAY.blit(alienImg[a['costume']], a['position'])
  
    if time.time() - lastBeamUpdateTime > BEAM_UPDATE_DELAY:
        for b in beams:
            if b[1] > 10:
                b[1] = b[1] - 10
            else:
                beams.remove(b)
        lastBeamUpdateTime = time.time()
    
    if time.time() - lastAlienUpdateTime > ALIEN_UPDATE_DELAY:
        for a in aliens:
            if a['position'][1] < 350:
                a['position'][0] += random.randint(-10, 10)
                a['position'][1] += 10
            else:
                aliens.remove(a)
        lastAlienUpdateTime = time.time()
    
    if time.time() > nextAlienStartTime:
        alien = { 'costume': random.randint(0,9),
                  'position': [random.randint(0, 479), 20] }
        aliens.append(alien)
        nextAlienStartTime = time.time() + random.randint(4, 8)

    for event in pygame.event.get():
        if pygame.key.get_pressed()[pygame.K_LEFT] != 0:
            if rx > 0:
                rx = rx - 10
        elif pygame.key.get_pressed()[pygame.K_RIGHT] != 0:
            if rx < 430:
                rx = rx + 10
        if pygame.key.get_pressed()[pygame.K_SPACE] != 0:
            beams.append([rx+30,ry])
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
    
    pygame.display.update()

