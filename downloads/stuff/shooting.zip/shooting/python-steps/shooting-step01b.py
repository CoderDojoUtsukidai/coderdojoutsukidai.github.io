import pygame, sys
from pygame.locals import *

BLACK = (0,0,0)

pygame.init()
DISPLAY = pygame.display.set_mode((480,360))

while True:
    DISPLAY.fill(BLACK)

    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
    
    pygame.display.update()

