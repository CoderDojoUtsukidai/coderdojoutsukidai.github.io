import pygame, sys, time, random
from pygame.locals import *

# ロケットの画像を読み込む
rocketImg = pygame.image.load('images/rocket1.png')
rx = 210
ry = 240

# ビームの初期化
beams = []
lastBeamUpdateTime = 0
BEAM_UPDATE_DELAY = 0.1 # sec

# エイリアンの画像を読み込む
alienImg = []
for i in range(10):
    alienImg.append(pygame.image.load('images/alien'+str(i+1)+'.png'))

# エイリアンの初期化
aliens = []
lastAlienUpdateTime = 0
ALIEN_UPDATE_DELAY = 0.5 # sec
nextAlienStartTime = time.time() + 6

# 色やフォントの定義
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

# ゲームの初期化
pygame.init()
pygame.key.set_repeat(100,50) # キーを押しっぱなしにする時の繰り返し頻度
DISPLAYSURF = pygame.display.set_mode((480, 360))
BASICFONT = pygame.font.Font('freesansbold.ttf', 24)

while True:
    ### 描画 ###
    
    # 背景を描く
    DISPLAYSURF.fill(BLACK)
    # ロケットを描く
    DISPLAYSURF.blit(rocketImg, (rx, ry))
    # ビームを描く
    for b in beams:
        pygame.draw.rect(DISPLAYSURF, WHITE, (b[0]-2, b[1]-8, 4, 16))
    # エイリアンを描く
    for a in aliens:
        DISPLAYSURF.blit(alienImg[a['costume']], a['position'])

    ### 次の状態を決める ###
    
    # ビームを動かす
    if time.time() - lastBeamUpdateTime > BEAM_UPDATE_DELAY:
        for b in beams:
            if b[1] > 10:
                b[1] = b[1] - 10
            else:
                beams.remove(b)
        lastBeamUpdateTime = time.time()
    # エイリアンを動かす
    if time.time() - lastAlienUpdateTime > ALIEN_UPDATE_DELAY:
        for a in aliens:
            if a['position'][1] < 350:
                a['position'][0] += random.randint(-10, 10)
                a['position'][1] += 10
            else:
                aliens.remove(a)
        lastAlienUpdateTime = time.time()
    # ビームがエイリアンにあたったかどうかを確認する
    for b in beams:
        for a in aliens:
            alienPos = a['position']
            if alienPos[0] - 30 < b[0] < alienPos[0] + 30 and \
               alienPos[1] < b[1] < alienPos[1] + 60:
                aliens.remove(a)
                beams.remove(b)
    # エイリアンがロケットにあたったかどうかを確認する
    for a in aliens:
        alienPos = a['position']
        if alienPos[0] - 40 < rx < alienPos[0] + 40 and \
           alienPos[1] >= ry - 40:
            pressKeySurf = BASICFONT.render('GAME OVER', True, WHITE)
            pressKeyRect = pressKeySurf.get_rect()
            pressKeyRect.center = (240, 180)
            DISPLAYSURF.blit(pressKeySurf, pressKeyRect)
            pygame.display.update()
            time.sleep(3)
            pygame.quit()
            sys.exit()
    # 次のエイリアンを表示する
    if time.time() > nextAlienStartTime:
        alien = { 'costume': random.randint(0,9), 'position': [random.randint(0, 479), 20] }
        aliens.append(alien)
        nextAlienStartTime = time.time() + random.randint(4, 8)

    ### キーボード操作を処理する ###
    
    for event in pygame.event.get():
        if pygame.key.get_pressed()[pygame.K_LEFT] != 0:
            # 左へ行く
            if rx > 0:
                rx = rx - 10
        elif pygame.key.get_pressed()[pygame.K_RIGHT] != 0:
            # 右へ行く
            if rx < 430:
                rx = rx + 10
        if pygame.key.get_pressed()[pygame.K_SPACE] != 0:
            # シュートする
            beams.append([rx+30,ry])
        if event.type == QUIT:
            # ゲームを終了する
            pygame.quit()
            sys.exit()

    # 画面を更新する
    pygame.display.update()



